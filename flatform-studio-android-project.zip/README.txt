FlatForm Studio - Android project (version 1.3)

New in 1.3: anonymous usage statistics (only after the person taps Allow in the privacy notice; Privacy button in the app lets them turn it off and delete their data).
The APK is now built signed with a permanent key, and is named FlatFormStudio.apk.

Setup is explained step by step in the FlatForm Studio tracking setup guide.
In short: upload this zip as flatform-studio-android-project.zip, add the secret KEYSTORE_PASSWORD and the variables TRACKING_URL and TRACKING_KEY in GitHub,
use the workflow text from the guide, and run it. Until TRACKING_URL is set, the app works normally and shows no notice.

IMPORTANT: switching to the permanent key means people who have an older build must uninstall it once (export Presets as JSON first). After that, updates install over the old app.
Requires Android 10 or newer.
