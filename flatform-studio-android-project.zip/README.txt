FlatForm Studio - Android project (version 1.2)

Reference image section: Add image from files, Copy and paste, Clear image.

Build the APK on GitHub (no Android Studio needed):
1. Upload this zip as one file to a public GitHub repository (the same name replaces the old one).
2. Add .github/workflows/build-apk.yml (text is in the chat).
3. Open Actions, wait for the green tick, download the FlatFormStudio-apk artifact, unzip it and install app-debug.apk.

IMPORTANT when updating: every GitHub build is signed with a new key, so Android will not install it over an older build.
Open the old app first and use Presets > Export JSON to back up. Uninstall the old app, install the new one, then Import JSON.

Or build with Android Studio: open this folder, Build > Build APK(s). Requires Android 10 or newer.
