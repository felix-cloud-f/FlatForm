FlatForm Studio - Android project
1. Install Android Studio (https://developer.android.com/studio) and open this folder.
2. Wait for Gradle sync to finish (needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at app/build/outputs/apk/debug/app-debug.apk - copy it to your phone and install it.
   (Allow "install unknown apps" for your file manager when asked.)
For Play Store release use Build > Generate Signed Bundle / APK.
Requires Android 10 or newer. The app works offline; presets are stored on the device.

NO ANDROID STUDIO? Build the APK online for free with GitHub:
1. Create a new GitHub repository and upload everything in this folder (keep the .github folder).
2. Open the repository's Actions tab. The "Build APK" workflow runs automatically (about 3-5 minutes).
3. Open the finished run and download "FlatFormStudio-apk" from Artifacts. Unzip it to get app-debug.apk.
